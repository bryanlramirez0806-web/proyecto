package polizas.Submarcas;

import java.sql.SQLException;
import java.util.*;
import polizas.General.Conexion;
import polizas.General.DAO;

public class SubmarcaModelo extends Conexion implements DAO {
    @Override public List read() {
        List<Submarca> l = new ArrayList<>();
        try {
            conectar();
            ps = cnx.prepareStatement("SELECT * FROM submarca");
            rs = ps.executeQuery();
            while(rs.next()) {
                l.add(new Submarca(rs.getInt(1), rs.getInt(2), rs.getString(3), rs.getBoolean(4)));
            }
        } catch(SQLException e) {} finally { close(); }
        return l;
    }
    @Override public int create(Object obj) {
        try {
            conectar(); Submarca s = (Submarca) obj;
            ps = cnx.prepareStatement("INSERT INTO submarca (idMarca, nombreSubmarca, activo) VALUES (?, ?, ?)");
            ps.setInt(1, s.getIdMarca());
            ps.setString(2, s.getNombreSubmarca());
            ps.setBoolean(3, true);
            return ps.executeUpdate();
        } catch(SQLException e) { return 0; } finally { close(); }
    }
    @Override public int update(Object obj) {
        try {
            conectar(); Submarca s = (Submarca) obj;
            ps = cnx.prepareStatement("UPDATE submarca SET idMarca = ?, nombreSubmarca = ? WHERE idSubmarca = ?");
            ps.setInt(1, s.getIdMarca());
            ps.setString(2, s.getNombreSubmarca());
            ps.setInt(3, s.getIdSubmarca());
            return ps.executeUpdate();
        } catch(SQLException e) { return 0; } finally { close(); }
    }
    @Override public int delete(Object obj) {
        try {
            conectar(); Submarca s = (Submarca) obj;
            ps = cnx.prepareStatement("DELETE FROM submarca WHERE idSubmarca = ?");
            ps.setInt(1, s.getIdSubmarca());
            return ps.executeUpdate();
        } catch(SQLException e) { return 0; } finally { close(); }
    }
}